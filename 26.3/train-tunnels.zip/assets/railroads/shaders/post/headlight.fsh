#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D SceneSampler;
uniform sampler2D DepthSampler;
uniform sampler2D ActiveSampler;
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;

bool signature(int row) {
    return ivec3(round(texelFetch(SceneSampler, ivec2(8,row), 0).rgb*255.0)) == ivec3(137,row,211);
}
float scalar(int x, int row) {
    uvec3 b = uvec3(round(texelFetch(SceneSampler, ivec2(x,row),0).rgb*255.0));
    return uintBitsToFloat((b.r<<24) | (b.g<<16) | (b.b<<8));
}
vec3 point(int row) {
    return vec3(scalar(9,row),scalar(10,row),scalar(11,row));
}
void main() {
    fragColor = texture(SceneSampler,texCoord);
    ivec2 p = ivec2(gl_FragCoord.xy);
    if (any(lessThan(textureSize(SceneSampler,0),ivec2(29,27)))) return;
    if (p.x >= 8 && p.x < 28 && p.y >= 8 && p.y <= 25 && signature(p.y)) {
        fragColor = texelFetch(SceneSampler,ivec2(p.x < 18 ? 7 : 28,p.y),0);
        return;
    }
    ivec2 bits = ivec2(round(texelFetch(ActiveSampler,ivec2(0),0).rg * 255.0));
    int mask = bits.r | (bits.g << 8);
    if (mask == 0) return;
    float depth = texture(DepthSampler,texCoord).r;
    if (depth == 0.0) return;
    // All train markers share this camera's projection. Decode it only once.
    int cameraRow = 8;
    while ((mask & (1 << ((cameraRow - 8) / 2))) == 0) cameraRow += 2;
    mat4 invProj;
    for (int i=0;i<16;i++) invProj[i/4][i%4] = scalar(12+i,cameraRow);
#ifndef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
    depth = depth*2.0-1.0;
#endif
    vec4 position = invProj * vec4(texCoord*2.0-1.0,depth,1.0);
    vec3 surface = position.xyz / position.w;
    float beam = 0.0;
    for (int slot=0;slot<=8;slot++) {
        if ((mask & (1 << slot)) == 0) continue;
        int row = 8 + slot * 2;
        vec3 lamp = point(row);
        vec3 axis = point(row + 1) - lamp;
        float span = length(axis);
        if (!(span > 0.2 && span < 4.0)) continue;
        axis /= span;
        vec3 offset = surface - lamp;
        float along = dot(offset,axis);
        if (!(along > 0.0 && along < 18.0)) continue;
        float radius = 0.35 + along * 0.46;
        float radialDistance = length(offset - axis * along);
        beam = max(beam, (1.0 - smoothstep(radius * 0.45, radius, radialDistance))
                        * (1.0 - smoothstep(5.0, 18.0, along)));
    }
    fragColor.r += beam * (0.19 + 0.55 * fragColor.r) * (1.0 - fragColor.r);
}
