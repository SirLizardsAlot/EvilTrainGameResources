#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D SceneSampler;
uniform sampler2D DepthSampler;
uniform sampler2D ActiveSampler;
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;

bool signature(int row) {
    return ivec3(round(texelFetch(SceneSampler, ivec2(8,row), 0).rgb*255.0)) == ivec3(137,row,211);
}
float scalar(int x, int row) {
    uvec3 b = uvec3(round(texelFetch(SceneSampler, ivec2(x,row),0).rgb*255.0));
    return uintBitsToFloat((b.r<<24) | (b.g<<16) | (b.b<<8));
}
vec3 point(int row) {
    return vec3(scalar(9,row),scalar(10,row),scalar(11,row));
}
void main() {
    fragColor = texture(SceneSampler,texCoord);
    ivec2 p = ivec2(gl_FragCoord.xy);
    if (any(lessThan(textureSize(SceneSampler,0),ivec2(29,27)))) return;
    if (p.x >= 8 && p.x < 28 && p.y >= 8 && p.y <= 25 && signature(p.y)) {
        fragColor = texelFetch(SceneSampler,ivec2(p.x < 18 ? 7 : 28,p.y),0);
        return;
    }
    ivec2 bits = ivec2(round(texelFetch(ActiveSampler,ivec2(0),0).rg * 255.0));
    int mask = bits.r | (bits.g << 8);
    if (mask == 0) return;
    // All train markers share this camera's projection. Decode it only once.
    int cameraRow = 8;
    while ((mask & (1 << ((cameraRow - 8) / 2))) == 0) cameraRow += 2;
    mat4 invProj;
    for (int i=0;i<16;i++) invProj[i/4][i%4] = scalar(12+i,cameraRow);
    vec2 ndc = texCoord * 2.0 - 1.0;
    vec4 nearPoint = invProj * vec4(ndc, 1.0, 1.0);
    vec3 ray = normalize(nearPoint.xyz / nearPoint.w);
    float depth = texture(DepthSampler, texCoord).r;
    bool hasSurface = depth > 0.0; // Both 26.3 backends use reverse Z.
    float surfaceDistance = 0.0;
    vec3 surface = vec3(0.0);
    if (hasSurface) {
#ifndef RENDERPEARL_DEPTH_IS_ZERO_TO_ONE
        depth = depth * 2.0 - 1.0;
#endif
        vec4 position = invProj * vec4(ndc, depth, 1.0);
        surface = position.xyz / position.w;
        surfaceDistance = length(surface);
    }
    vec3 normal = cross(dFdx(surface), dFdy(surface));
    normal /= max(length(normal), 0.000001);
    if (dot(normal, -surface) < 0.0) normal = -normal;
    vec3 light = vec3(0.0);
    for (int slot=0;slot<=8;slot++) {
        if ((mask & (1 << slot)) == 0) continue;
        int row = 8 + slot * 2;
        vec3 lamp = point(row);
        vec3 axis = point(row + 1) - lamp;
        float span = length(axis);
        if (!(span > 0.2 && span < 4.0)) continue;
        axis /= span;
        // The red lens is visible head-on even with sky behind it. Stop the halo
        // at nearer geometry, allowing the lens face to sit on its own housing.
        float lensDistance = dot(lamp, ray);
        float facing = smoothstep(0.0, 0.55, dot(axis, -ray));
        if (lensDistance > 0.0 && facing > 0.0 &&
            (!hasSurface || lensDistance <= surfaceDistance + 0.16)) {
            float miss = length(lamp - ray * lensDistance);
            float halo = 1.0 - smoothstep(0.15, 0.90, miss);
            light += vec3(1.10, 0.08, 0.035) * halo * halo * facing;
        }
        if (!hasSurface) continue;
        vec3 offset = surface - lamp;
        float along = dot(offset,axis);
        if (!(along > 0.0 && along < 18.0)) continue;
        float radius = 0.35 + along * 0.46;
        float radialDistance = length(offset - axis * along);
        float beam = (1.0 - smoothstep(radius * 0.45, radius, radialDistance))
                   * (1.0 - smoothstep(5.0, 18.0, along));
        float incidence = max(0.0, dot(normal, -normalize(offset)));
        light += vec3(1.0, 0.045, 0.018) * beam * sqrt(incidence);
    }
    // Independent lamps contribute to the same wall without clipping to white.
    fragColor.rgb += (1.0 - fragColor.rgb) * (1.0 - exp(-light));
}
