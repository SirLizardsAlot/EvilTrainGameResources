#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D SceneSampler;
layout(location = 0) out vec4 fragColor;

bool present(int row) {
    return ivec3(round(texelFetch(SceneSampler, ivec2(8,row), 0).rgb * 255.0)) == ivec3(137,row,211);
}
void main() {
    int mask = 0;
    if (all(greaterThanEqual(textureSize(SceneSampler,0), ivec2(29,27)))) {
        for (int slot = 0; slot <= 8; ++slot) {
            int row = 8 + slot * 2;
            if (present(row) && present(row + 1)) mask |= 1 << slot;
        }
    }
    fragColor = vec4(float(mask & 255), float(mask >> 8), 0, 255) / 255.0;
}
