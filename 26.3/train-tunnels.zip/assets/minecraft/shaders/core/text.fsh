#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

#ifdef IS_SEE_THROUGH
#include <minecraft:projection.glsl>
layout(location = 4) flat in int markerRow;
layout(location = 5) in vec3 markerView;
#endif

void main() {

#if defined(IS_SEE_THROUGH) && !defined(OIT_ALPHA_ONLY)
    if (markerRow != 0) {
        int column = int(gl_FragCoord.x) - 8;
        vec3 center = markerView + (18.0 - gl_FragCoord.x) * dFdx(markerView);
        if (column == 0) {
            fragColor = vec4(137, markerRow, 211, 255) / 255.0;
        } else {
            int i = clamp(column - 4, 0, 15);
            float value = column <= 3 ? center[clamp(column-1,0,2)] : inverse(ProjMat)[i/4][i%4];
            uint bits = floatBitsToUint(value);
            fragColor = vec4((uvec3(bits >> 24, bits >> 16, bits >> 8) & 255u), 255u) / 255.0;
        }
        return;
    }
#endif

    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
