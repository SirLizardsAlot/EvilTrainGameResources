#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

#ifdef IS_SEE_THROUGH
#include <minecraft:globals.glsl>
layout(location = 4) flat out int markerRow;
layout(location = 5) out vec3 markerView;
#endif

void main() {

#ifdef IS_SEE_THROUGH
    ivec3 rgb = ivec3(round(Color.rgb * 255.0));
    // The /light probe has its own pair. Moving trains use eight other pairs.
    int slot = rgb.g == 17 ? 0 : rgb.g - 32;
    bool reserved = rgb.g == 17 || (rgb.g >= 33 && rgb.g <= 40);
    markerRow = reserved && rgb.r == 253 && (rgb.b == 71 || rgb.b == 72)
        ? 8 + slot * 2 + rgb.b - 71 : 0;
    if (markerRow != 0) {
        const vec2 corners[4] = vec2[4](vec2(0,1),vec2(0,0),vec2(1,0),vec2(1,1));
        vec2 pixel = vec2(8, markerRow) + corners[gl_VertexIndex % 4] * vec2(20, 1);
        gl_Position = vec4(2.0 * pixel / ScreenSize - 1.0, 0.5, 1.0);
        markerView = (ModelViewMat * vec4(Position, 1.0)).xyz;
        vertexColor = vec4(1);
        texCoord0 = UV0;
        return;
    }
    markerView = vec3(0);
#endif

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
